#!/bin/bash
echo 'Uping interface'
sudo ifconfig -a wlxc8be1906ef6f up>/dev/null
echo 'Interface UP complite!'
echo 'Starting network.'
sudo wpa_supplicant -i wlxc8be1906ef6f -Dwext  -c wpa.conf>/dev/null & sudo dhclient wlxc8be1906ef6f>/dev/null
echo 'Network is start complite!'
